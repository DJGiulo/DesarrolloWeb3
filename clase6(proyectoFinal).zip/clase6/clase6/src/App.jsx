import { useState } from 'react'
import './App.css'
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom'
import UserList from '../components2/userList'
import Navbar from '../components2/navBar'
import UserDetails from '../components2/userDetail'
import UserEdit from '../components2/userEdit'
import UserForm from '../components2/userForm1'
import UserDelete from '../components2/userDelete'
/*import Home from '../pages/home'
import About from '../pages/about'
import Contact from '../pages/contact'
import { ProveedorDeTareas } from './context/proveedorDeTareas'*/

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Router>
      <Navbar/>
      <h1>Gestión de Usuarios</h1>
      <p>Aplicación para gestionar usuarios</p>
      <Routes>
        <Route path="/" element={<UserList />} />
        <Route path="/users/:id" element={<UserDetails />} />
        <Route path="/create" element={<UserForm />} />
        <Route path="/edit/:id" element={<UserEdit />} />
        <Route path="/delete/:id" element={<UserDelete />} />
      </Routes>
    </Router>
    </>
  )

/*
  return (
    <>
    <UserList/>
    <ProveedorDeTareas>
      <Router>
        <NavBar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/about' element={<About/>}/>
          <Route path='/contact' element={<Contact/>}/>
        </Routes>
      </Router>
    </ProveedorDeTareas>
    </>
  )*/
}

export default App;