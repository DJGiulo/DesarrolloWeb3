import React, { useState, useEffect } from "react"

const UserList = () => {

    return (
        <div>
            <h2>Lista de usuarios</h2>
            {
                loading ?
                    (<h1>cargando...</h1>)
                    :
                    (<ul>
                        {users.map = (users) => (
                            <li key={users.id}>
                                {users.name}
                                <span> - {user.email}</span>
                                <Link to={`/users/${users.id}`}>Ver detalles</Link>
                            </li>)}
                    </ul>)
            }
            <div>
                <input type="text"
                    value={newUserNameuser}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="nombre del usuario"
                />
                {
                    selectedUser ?
                        (<button onClick={handleDeleteUser}>Actualizar usuario</button>)
                        :
                        (<button onClick={createNewUser}>crear usuario</button>)
                }
            </div>
        </div>
    )
}

export default UserList;