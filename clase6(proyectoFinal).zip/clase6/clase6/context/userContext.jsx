import React, { createContext, useState, useEffect } from 'react';

export const UserContext = createContext();
/*    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newUserName, setUserName] = useState('');
    const [selectedUser, setSelectedUser] = useState(null);
    const apiURL = "https://68360343664e72d28e3f9ded.mockapi.io/user/usuario"

    
    useEffect(() => {
        fetch(apiURL)
        .then((response)=>response.json())
        .then(data => {
            setLoading(false)
            setUsers(data)})
        .catch((error)=> {
            setLoading(false)
            console.log("error al obtener usuarios:", error)});
        
    },[apiURL])

    //console.log(users);
    
    //crear nuevo usuario

    const createNewUser=() => {
        fetch(apiURL, {
            method:'POST',
            headers : {
                'content-Type' :'application/json'
            },
            body:JSON.stringify({name:newUserNameusername})
        })
        .then (res=> res.json)
        .then (()=>{
            setUserName('')
        })

        .then(()=>{
            return fetch(apiURL)
        })
        .then((response)=>response.json())
        .then(data => {
            setUsers(data)})
        .catch((error)=> {
            console.log("error al obtener usuarios:", error)});
    }


    //modificar algun dato

    const handleUpdateUser = () => {
        if (!selectedUser) return;
        // Realizar solicitud PUT para actualizar un usuario existente
                        //el select elije al usuario
        fetch(`${apiURL}/${selectedUser.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',

            },
            body: JSON.stringify({ name: newUserName }),
        })
            .then((response) => response.json())
            .then((updatedUser) => {
                // Actualizar el estado con el usuario actualizado
                setUsers(users.map((user) => (user.id === selectedUser.id ? updatedUser : user)));
                setNewUserName('');
                setSelectedUser(null);
            })
            .catch((error) => console.error('Error al actualizar usuario:', error));
    };


    //eliminar un dato

    const handleDeleteUser = (userId) => {
        // Realizar solicitud DELETE para eliminar un usuario
        fetch(`${apiURL}/${userId}`, {
            method: 'DELETE',
        })
            .then(() => {
                // Actualizar el estado excluyendo al usuario eliminado
                setUsers(users.filter((user) => user.id !== userId));
                setNewUserName('');
                setSelectedUser(null);
            })
            .catch((error) => console.error('Error al eliminar usuario:', error));
    };
*/

export const UserProvider = ({ children }) => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newUserName, setNewUserName] = useState('');
    const [selectedUser, setSelectedUser] = useState(null);
    const apiUrl = "https://684876bfec44b9f34940fd09.mockapi.io/usuarios/users/"; // Reemplaza con la URL de tu API de MockAPI.io

    useEffect(() => {
        fetch(apiUrl)
            .then((response) => response.json())
            .then(data => setUsers(data))
            .catch((error) => console.error("Error al obtener usuarios:", error))
            .finally(() => {
                setLoading(false);
            });
    }, [apiUrl]);

    // console.log('Usuarios cargados:', users);

    const handleCreateUser = (newUser) => {
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newUser),
        })
            .then((response) => response.json())
            .then((createdUser) => {
                setUsers([...users, createdUser]); // agregamos al final
            })
            .catch((error) => console.error(error.message));
    };

//Falta codigo agregar abajo de esta linea-----

const handleUpdateUser=(userId, updatedData)=>{
    fetch('${apiURL}/${userId}', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(updatedData)
    })
    .then(response => response.json())
    .then((updatedUser) => {
        setUsers(users.map(user => user.id === userId ? updatedUser : user));
        setSelectedUser(null);
    })
    .catch((error) => {
        console.error("Error al actualizar usuario:", error);
    });
}

const handleDeleteUser=(userId)=>{
    fetch('${apiURL}/${userId}', {
        method: 'DELETE'
    })
    .then(() => {
        setUsers(users.filter(user => user.id !== userId));
        setNewUserName('');
        setSelectedUser(null);
    })
    .catch((error) => {
        console.error("Error al eliminar usuario:", error);
    });
}

    return (
        <UserContext.Provider value={{
            users, loading, setUsers,
            newUserName, setNewUserName, handleCreateUser, handleUpdateUser,
            selectedUser, setSelectedUser, handleDeleteUser
        }}>

            {children}
        </UserContext.Provider>
    );
};
