import React from 'react'
import { Link } from 'react-router-dom'

const NavBar = () => {
    return (
        <nav>
            <ul>
            <li><link to='/'>Home</link></li>
            <li><Link to='/about'>About</Link></li>
            <li><link to='/contact'>Contact</link></li>
            </ul>
        </nav>
    )
    }

export default NavBar
