import {createContext } from "react";

const tareasContext = createContext();

const ProveedorDeTareas = ({Children}) => {

    let nombre = 'Juan';


    return(
        <tareasContext.Provider value={{nombre}}>
            {Children}
        </tareasContext.Provider>
    )
}

export {tareasContext, ProveedorDeTareas};