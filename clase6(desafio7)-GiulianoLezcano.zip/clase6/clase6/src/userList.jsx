import React, {useState, useEffect} from "react"

const UserList = () =>{
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newUserName, setUserName] = useState('');
    const [selectedUser, setSelectedUser] = useState(null);
    const apiURL = "https://68360343664e72d28e3f9ded.mockapi.io/user/usuario"

    
    useEffect(() => {
        fetch(apiURL)
        .then((response)=>response.json())
        .then(data => {
            setLoading(false)
            setUsers(data)})
        .catch((error)=> {
            setLoading(false)
            console.log("error al obtener usuarios:", error)});
        
    },[apiURL])

    //console.log(users);
    
    //crear nuevo usuario

    const createNewUser=() => {
        fetch(apiURL, {
            method:'POST',
            headers : {
                'content-Type' :'application/json'
            },
            body:JSON.stringify({name:newUserNameusername})
        })
        .then (res=> res.json)
        .then (()=>{
            setUserName('')
        })

        .then(()=>{
            return fetch(apiURL)
        })
        .then((response)=>response.json())
        .then(data => {
            setUsers(data)})
        .catch((error)=> {
            console.log("error al obtener usuarios:", error)});
    }


    //modificar algun dato

    const handleUpdateUser = () => {
        if (!selectedUser) return;
        // Realizar solicitud PUT para actualizar un usuario existente
                        //el select elije al usuario
        fetch(`${apiURL}/${selectedUser.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',

            },
            body: JSON.stringify({ name: newUserName }),
        })
            .then((response) => response.json())
            .then((updatedUser) => {
                // Actualizar el estado con el usuario actualizado
                setUsers(users.map((user) => (user.id === selectedUser.id ? updatedUser : user)));
                setNewUserName('');
                setSelectedUser(null);
            })
            .catch((error) => console.error('Error al actualizar usuario:', error));
    };


    //eliminar un dato

    const handleDeleteUser = (userId) => {
        // Realizar solicitud DELETE para eliminar un usuario
        fetch(`${apiURL}/${userId}`, {
            method: 'DELETE',
        })
            .then(() => {
                // Actualizar el estado excluyendo al usuario eliminado
                setUsers(users.filter((user) => user.id !== userId));
                setNewUserName('');
                setSelectedUser(null);
            })
            .catch((error) => console.error('Error al eliminar usuario:', error));
    };




    return(
    <div>
        <h2>Lista de usuarios</h2>
        {
            loading ?
            (<h1>cargando...</h1>)
            :
            (<ul>
                {users.map=(users)=>(
                    <li key={users.id}>
                        {users.name}
                        <button onClick={()=>handleDeleteUser(users.id)}>Eliminar</button>
                    </li>
                )}
            </ul>)
        }
        <div>
            <input type="text" 
            value={newUserNameuser}
            onChange={(e) => setNewUserName(e.target.value)}
                placeholder="nombre del usuario"
            />
            {
                selectedUser ?
                (<button onClick={handleDeleteUser}>Actualizar usuario</button>)
                :
                (<button onClick={createNewUser}>crear usuario</button>)
            }
        </div>
    </div>
    )
}

export default UserList;